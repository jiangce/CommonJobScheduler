# -*- coding: utf-8 -*-

from job_service.ui.uiDialogLog import Ui_DialogLog